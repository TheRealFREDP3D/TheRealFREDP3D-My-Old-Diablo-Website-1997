*Diablo Archive Viewer version 1.40, created by Lucifer*

**New in 1.40**

haha! I lets you view the saved games, but not SAVE them.
The reason I did this was because Enigma's backup was
supposed to be just that. A backup. And he turned it into
something Blizzard hated (and personally, I dont want
Blizzard mad at me for this).and btw, It is STILL encrypted
after you extract it. I'll make it decrypt itself for you
someday.

You dont need the hacked version of Storm.dll anymore.
It will work with any version of Diablo out now, and
(hopefully) any version from now on. It CAN view the
HYBRID.EXE cracked version, but use their version
of storm.dll to open it.

I have incorperated scripting for the file viewing.
Take a look at the program and the sample scripts to
see how to use them.

In the previous version of this viewer, there was a bug
that didn't allow you to View any file over 10Mb. This 
has been fixed.I also fixed the bug of it running in the 
background even after you closed it.

I am now using cleaner and more efficient code. That
means nothing to you, except I can pinpoint problems 
alot easier now.

**Things to Know**

If you haven't noticed I'm trying to make this program
do all the hard work for you. (You'll see in version
1.60). Now I'd like all of your cooperation when I say:
If you find another file I missed, or have figured out
what 'this' does and 'that' does in a file, Great! Send
it to me and I'll use it next time.

I have incorporated plugins like enigma did, and they are
be used like enigma's AND a new thing.
Put a .dll in the current dir called 
???.dll (eg. wav.dll cel.dll)
and a subfunction called
int Run(char* name, char* data, int size)

Another thing. To Use this, you need to put this in your
Diablo Dir. And if it ever comes that you HAVE to have it in a 
separate dir, then copy the storm.dll from the Diablo dir
to it's dir.

If the next release of Diablo changes things around so you cant
use it with that version,copy a 1.00 or 1.02 storm.dll into it's
directory and it will.(but I dunno about the saved games)

btw, for all those wanting to know something intersting...
The Saved game files are only 1288 in size.
The Saved game data (hero) is STILL encrypted.
The Archive is NOT compressed, just encrypted.

**One known Bug**

Whenever you open an MPQ file, every once in a while it will say
it has commited an illegal operation. I dont know why it's doing
it, because I didn't modify code that in any way. Please confirm
this so I can fix it. It might be my cheap ass computers I have. 


**To come in v1.60**
By then, I will probably have let you view your saved game files,
decryping it and all. It will also allow you to make your own
MPQ files. This making of your own MPQ files MIGHT allow you
to play this off your hard drive.I will also try and try again
to find every single file in the MPQ. I am employing a new search
method and it will be alot faster and easier to see what it's found.


**Info**
My name is Lucifer to all that email me. I couldn't have done
as near as much work without sorti. He is the one that gave
me the other 1000 files I didn't know of, and the help I have
gotten so far...
And I'm only 16.

email:lucifer_16@hotmail.com