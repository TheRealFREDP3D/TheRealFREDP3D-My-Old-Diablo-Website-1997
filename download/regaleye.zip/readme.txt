*** REye 1.1b for Windows 95 ***


 You cannot hold the programmer of this 
 program responsible for  ANYTHING that
 this program does.

 REye 1.1b is copyrighted freeware. 

 Diablo and Battle.net are trademarks and 
 Blizzard Entertainment is a registered trademark 
 of Davidson and Associates, Inc.
 DIABLO is Copyrighted(c), 1996 by 
 Blizzard Entertainment all right reserved.

**************** Installation ************************************

The installation of REye is simple:
UnZip the file REYE.ZIP in a new directory.

******************************************************************

DEye scans
- strength, magic, dexterity, vitality and gold of the players in the current channel.
- strength, magic, dexterity, vitality and gold of the players in the current "suggested games" page

P+ is the difference between 
  85 points (start) + 5 points/level
and 
  the current val. (str+mag+dex+vit).

Example:
   
   Strength:  120
   Magic:     230
   Dexterity: 115
   Vitality : 132
   Level:      32
 
   85 + 31*5 = 240      (-> Str+Mag+Dex+Vit _without_ items)

   120+230+115+132= 597 (-> Str+Mag+Dex+Vit _with_ items and elixirs)

   P+ = 597-240 = 357

   0       : This is an new Player
   1..250  : Average equipment
   251..400: Good equipment
   400..490: Very good equipment
   >500    : Many elixirs(!) or Cheat


******************************************************************


EMail: foxt@lcc.net


